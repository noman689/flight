import { Col, Row } from 'antd';
import React from 'react';

const FlightDetailsNav = ({ apiData }) => {
  return (
    <div>
      <Row justify="center"></Row>
    </div>
  );
};

export default FlightDetailsNav;
