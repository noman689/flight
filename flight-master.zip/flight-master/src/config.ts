export const SERVER_URL = 'https://flight-management-backend.vercel.app';
export const API_TOKEN = 'duffel_test_Uh48ncnbR0dwmqAIODjC3aYC9Em-LxgqAsMB98u9kPD';
